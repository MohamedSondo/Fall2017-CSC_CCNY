function [ diff ] = SUPPORT_CMP(matrixL, matrixR)    
    diff = SSD(matrixL, matrixR);
end